using System.ComponentModel.DataAnnotations;

namespace UserManagementService.Domain.Entities;

public class User
{
    [Key]
    public Guid Id { get; set; }
    public string? Name { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? Email { get; set; }

    public static User Create(Guid id, string name, string email)
    {
        User u = new()
        {
            Id = id,
            Name = name,
            Email = email
        };
        return u;
    }

    public static User Create(Guid id, string firstName, string lastName, string email)
    {        
        User u = new()
        {
            Id = id,
            FirstName = firstName,
            LastName = lastName,
            Email = email
        };
        return u;
    }
}
