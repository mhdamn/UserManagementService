﻿using UserManagementService.Application.Common.Mapper;
using UserManagementService.Application.Users.DTOs.Commands;
using UserManagementService.Application.Users.DTOs.Quries;
using UserManagementService.Domain.Entities;

namespace UserManagementService.Application.Helpers.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserDto>()
                .ForMember(d => d.Name, o => o.MapFrom(s => s.FirstName is not null || s.LastName is not null ? $"{s.FirstName} {s.LastName}" : s.Name))
                .ForMember(d => d.Email, o => o.MapFrom(s => s.Email)).ReverseMap();

            CreateMap<User, CreateUserRequestDto>();
        }
    }

}
