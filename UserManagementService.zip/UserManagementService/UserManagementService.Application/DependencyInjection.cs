using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Common.Mapper;
using UserManagementService.Application.Helpers.Pipeline;

namespace UserManagementService.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {

        var asm = AppDomain.CurrentDomain.GetAssemblies();

        services.AddCQRSHandlers(asm);
        services.AddMapper(asm);

        services.AddValidatorsFromAssemblies(asm);
        services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));


        return services;
    }
}
