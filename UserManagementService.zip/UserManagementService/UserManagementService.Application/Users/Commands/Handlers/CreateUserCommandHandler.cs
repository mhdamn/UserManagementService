using UserManagementService.Domain.Entities;
using UserManagementService.Application.Users.Events;
using UserManagementService.Application.Contracts.Repositories;
using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Common.Mapper;

namespace UserManagementService.Application.Users.Commands.Handlers;

public class CreateUserCommandHandler(IRepository<User> repo, IDispatcher events) : ICommandHandler<CreateUserCommand, Guid>
{
    private readonly IRepository<User> _repo = repo;
    private readonly IDispatcher _events = events;

    public async Task<Guid> Handle(CreateUserCommand command, CancellationToken cancellationToken)
    {
        User user = command.request.Map<User>();
        user.Id = Guid.NewGuid();
        await _repo.AddAsync(user);
        await _events.Publish(user.Map<UserCreatedEvent>(),cancellationToken);
        return user.Id;
    }
}
