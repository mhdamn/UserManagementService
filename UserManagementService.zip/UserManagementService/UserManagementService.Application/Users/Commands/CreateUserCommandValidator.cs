using FluentValidation;

namespace UserManagementService.Application.Users.Commands;

public class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
{
    public CreateUserCommandValidator()
    {
        RuleFor(x => x.request).NotNull()
            .SetValidator(new CreateUserRequestValidator());
    }
}
