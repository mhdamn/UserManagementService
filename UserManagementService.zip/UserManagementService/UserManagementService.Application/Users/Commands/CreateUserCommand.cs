using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Users.DTOs.Commands;
namespace UserManagementService.Application.Users.Commands;
public record CreateUserCommand(CreateUserRequestDto request) : ICommand<Guid>;
