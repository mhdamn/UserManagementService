using FluentValidation;
using UserManagementService.Application.Users.DTOs.Commands;

namespace UserManagementService.Application.Users.Commands;

public class CreateUserRequestValidator : AbstractValidator<CreateUserRequestDto>
{
    public CreateUserRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(100);
        RuleFor(x => x.Email).NotEmpty().EmailAddress();
    }
}
