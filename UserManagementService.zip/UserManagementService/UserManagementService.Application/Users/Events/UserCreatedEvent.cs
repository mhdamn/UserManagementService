using UserManagementService.Application.Common.CQRS;

namespace UserManagementService.Application.Users.Events;
public record UserCreatedEvent(Guid UserId, string Name, string Email) : IDomainEvent;
