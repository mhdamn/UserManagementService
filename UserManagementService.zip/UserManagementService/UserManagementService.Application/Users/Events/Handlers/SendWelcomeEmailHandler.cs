using UserManagementService.Application.Common.CQRS;

namespace UserManagementService.Application.Users.Events.Handlers;

public class SendWelcomeEmailHandler : IDomainEventHandler<UserCreatedEvent>
{
    public Task Handle(UserCreatedEvent @event, CancellationToken cancellationToken)
    {
        Console.WriteLine($"[Event] Welcome email queued for {@event.Name} ({@event.Email})");
        return Task.CompletedTask;
    }
}
