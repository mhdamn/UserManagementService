﻿namespace UserManagementService.Application.Users.DTOs.Commands
{
    public record CreateUserRequestDto(string Name, string Email);
}
