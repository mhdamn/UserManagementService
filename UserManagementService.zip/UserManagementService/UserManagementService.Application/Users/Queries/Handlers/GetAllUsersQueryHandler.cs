using Microsoft.EntityFrameworkCore;
using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Common.Mapper;
using UserManagementService.Application.Contracts.Repositories;
using UserManagementService.Application.Users.DTOs.Quries;
using UserManagementService.Domain.Entities;

namespace UserManagementService.Application.Users.Queries.Handlers;

public class GetAllUsersQueryHandler(IRepository<User> repo) : IQueryHandler<GetAllUsersQuery, PagedResult<UserDto>>
{
    private readonly IRepository<User> _repo = repo;

    public async Task<PagedResult<UserDto>> Handle(GetAllUsersQuery query, CancellationToken cancellationToken)
    {
        var q = _repo.AsQueryable();

        if (!string.IsNullOrWhiteSpace(query.NameFilter))
            q = q.Where(u => EF.Functions.Like(u.Name, $"%{query.NameFilter}%")
                        || EF.Functions.Like(u.FirstName, $"%{query.NameFilter}%")
                        || EF.Functions.Like(u.LastName, $"%{query.NameFilter}%"));

        var total = await q.CountAsync();
        var pageNumber = query.Paging?.PageNumber ?? 1;
        var pageSize = query.Paging?.PageSize ?? 10;

        var items = await q.Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .Select(u => u.Map<UserDto>())
            .ToListAsync();

        return new PagedResult<UserDto>(items, total, pageNumber, pageSize);
    }
}
