using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Common.Mapper;
using UserManagementService.Application.Contracts.Repositories;
using UserManagementService.Application.Users.DTOs.Quries;
using UserManagementService.Domain.Entities;

namespace UserManagementService.Application.Users.Queries.Handlers;

public class GetUserByIdQueryHandler(IRepository<User> repo) : IQueryHandler<GetUserByIdQuery, UserDto?>
{
    private readonly IRepository<User> _repo = repo;

    public async Task<UserDto?> Handle(GetUserByIdQuery query, CancellationToken cancellationToken)
    {
        var u = await _repo.GetByIdAsync(query.Id);
        return u is null ? null : u.Map<UserDto>();
    }
}
