using FluentValidation;

namespace UserManagementService.Application.Users.Queries;

public class GetAllUsersQueryValidator : AbstractValidator<GetAllUsersQuery>
{
    public GetAllUsersQueryValidator()
    {
        RuleFor(x => x.Paging).NotNull();
        When(x => x.Paging != null, () => {
            RuleFor(x => x.Paging!.PageNumber).GreaterThan(0);
            RuleFor(x => x.Paging!.PageSize).GreaterThan(0).LessThanOrEqualTo(100);
        });
        RuleFor(x => x.NameFilter).MaximumLength(100);
    }
}
