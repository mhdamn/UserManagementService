using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Users.DTOs.Quries;
namespace UserManagementService.Application.Users.Queries;
public record GetUserByIdQuery(Guid Id) : IQuery<UserDto?>;
