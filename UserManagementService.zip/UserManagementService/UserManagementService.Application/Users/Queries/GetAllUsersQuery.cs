using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Users.DTOs.Quries;
namespace UserManagementService.Application.Users.Queries;

public record PagingParameters(int PageNumber = 1, int PageSize = 10);
public record PagedResult<T>(IEnumerable<T> Items, int TotalCount, int PageNumber, int PageSize);
public record GetAllUsersQuery(PagingParameters? Paging = null, string? NameFilter = null) : IQuery<PagedResult<UserDto>>;
