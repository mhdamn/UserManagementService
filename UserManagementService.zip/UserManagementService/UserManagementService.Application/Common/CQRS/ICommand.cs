namespace UserManagementService.Application.Common.CQRS; 
public interface ICommand<TResult> { }