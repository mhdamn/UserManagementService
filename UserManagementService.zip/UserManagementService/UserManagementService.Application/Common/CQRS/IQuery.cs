namespace UserManagementService.Application.Common.CQRS; 
public interface IQuery<TResult> { }