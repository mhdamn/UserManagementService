using Microsoft.Extensions.DependencyInjection;

namespace UserManagementService.Application.Common.CQRS;

public class Dispatcher(IServiceProvider provider) : IDispatcher
{
    public async Task<TResult> Send<TResult>(ICommand<TResult> command, CancellationToken cancellationToken = default)
    {
        // Resolve the handler dynamically
        var handlerType = typeof(ICommandHandler<,>).MakeGenericType(command.GetType(), typeof(TResult));
        dynamic handler = provider.GetRequiredService(handlerType);

        // Define the final handler delegate
        RequestHandlerDelegate<TResult> finalHandler = ct => handler.Handle((dynamic)command, ct);
        return await RunPipeline(command, finalHandler, cancellationToken);
    }

    public async Task<TResult> Query<TResult>(IQuery<TResult> query, CancellationToken cancellationToken = default)
    {
        var handlerType = typeof(IQueryHandler<,>).MakeGenericType(query.GetType(), typeof(TResult));
        dynamic handler = provider.GetRequiredService(handlerType);

        RequestHandlerDelegate<TResult> finalHandler = ct => handler.Handle((dynamic)query, ct);

        return await RunPipeline(query, finalHandler, cancellationToken);
    }

    public async Task Publish<TEvent>(TEvent @event, CancellationToken cancellationToken = default) where TEvent : IDomainEvent
    {
        var handlers = provider.GetServices<IDomainEventHandler<TEvent>>();
        foreach (var h in handlers)
            await h.Handle(@event, cancellationToken);
    }

    private async Task<TResult> RunPipeline<TRequest, TResult>(TRequest request, RequestHandlerDelegate<TResult> finalHandler,
        CancellationToken cancellationToken)
    {
        // Dynamically resolve all pipeline behaviors for this request
        var behaviors = provider.GetServices(typeof(IPipelineBehavior<,>)
                            .MakeGenericType(request.GetType(), typeof(TResult)))
                            .Cast<dynamic>()
                            .Reverse()
                            .ToList();

        RequestHandlerDelegate<TResult> next = finalHandler;

        foreach (var behavior in behaviors)
        {
            var localNext = next;
            next = ct => behavior.Handle((dynamic)request, localNext, ct);
        }

        var response = await next(cancellationToken);
        GC.Collect();
        return response;
    }
}
