namespace UserManagementService.Application.Common.CQRS; 
public interface IDomainEvent { }