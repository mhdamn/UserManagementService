using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace UserManagementService.Application.Common.CQRS;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddCQRSHandlers(this IServiceCollection services, params Assembly[] assemblies)
    {
        foreach (var assembly in assemblies)
        {
            var types = assembly.GetTypes()
                .Where(t => !t.IsAbstract && !t.IsInterface)
                .Select(t => new
                {
                    Type = t,
                    Interfaces = t.GetInterfaces().Where(i =>
                        i.IsGenericType &&
                        (i.GetGenericTypeDefinition() == typeof(ICommandHandler<,>) ||
                         i.GetGenericTypeDefinition() == typeof(IQueryHandler<,>) ||
                         i.GetGenericTypeDefinition() == typeof(IDomainEventHandler<>))
                    ).ToArray()
                })
                .Where(x => x.Interfaces.Any());

            foreach (var t in types)
                foreach (var iface in t.Interfaces)
                    services.AddScoped(iface, t.Type);
        }

        services.AddScoped<IDispatcher, Dispatcher>();

        return services;
    }
}
