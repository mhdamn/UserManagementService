﻿using System.Linq.Expressions;
using System.Reflection;

namespace UserManagementService.Application.Common.Mapper
{
    public class MappingBuilder<TSource, TDestination>(Func<TSource, TDestination>? factory = null)
    {
        private Func<TSource, TDestination>? _factory = factory;

        private readonly List<IMappingAction<TSource, TDestination>> _mappings = new();

        public MappingBuilder<TSource, TDestination> ForMember<TMember>(
            Expression<Func<TDestination, TMember>> destinationMember,
            Func<MappingSource<TSource>, TMember>? mapFunc = null) // optional MapFrom wrapper
        {
            var propInfo = (destinationMember.Body as MemberExpression)?.Member as PropertyInfo;
            if (propInfo == null)
                throw new ArgumentException("Destination member must be a property");

            // Build typed setter
            var destParam = Expression.Parameter(typeof(TDestination), "d");
            var valueParam = Expression.Parameter(typeof(TMember), "v");
            var assign = Expression.Assign(Expression.Property(destParam, propInfo), valueParam);
            var setter = Expression.Lambda<Action<TDestination, TMember>>(assign, destParam, valueParam).Compile();

            if (mapFunc != null)
            {
                var getter = new Func<TSource, TMember>(src => mapFunc(new MappingSource<TSource>(src))!);
                _mappings.Add(new MappingAction<TSource, TDestination, TMember>(getter, setter));
            }
            else
            {
                var sourceProp = typeof(TSource).GetProperty(propInfo.Name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (sourceProp == null)
                    throw new InvalidOperationException($"No source property found for {propInfo.Name}");

                var srcParam = Expression.Parameter(typeof(TSource), "s");
                var srcAccess = Expression.Property(srcParam, sourceProp);
                var getterLambda = Expression.Lambda<Func<TSource, TMember>>(Expression.Convert(srcAccess, typeof(TMember)), srcParam);
                var getter = getterLambda.Compile();

                _mappings.Add(new MappingAction<TSource, TDestination, TMember>(getter, setter));
            }

            return this;
        }

        public MappingBuilder<TSource, TDestination> ForMember(PropertyInfo? destinationPropInfo)
        {
            if (destinationPropInfo == null)
                throw new ArgumentException("Destination member must be a property");

            // Use GetProperties + FirstOrDefault to make it more robust
            var sourceProp = typeof(TSource).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                                            .FirstOrDefault(p => string.Equals(p.Name, destinationPropInfo.Name, StringComparison.OrdinalIgnoreCase));

            if (sourceProp == null)
            {
                // Skip mapping instead of throwing OR handle manually
                return this;
            }

            // Get the destination property from TDestination by name (case-insensitive)
            var destProp = typeof(TDestination).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                                               .FirstOrDefault(p => string.Equals(p.Name, destinationPropInfo.Name, StringComparison.OrdinalIgnoreCase));

            if (destProp == null)
                return this; // skip if destination property not found

            // Build getter
            var srcParam = Expression.Parameter(typeof(TSource), "s");
            var srcAccess = Expression.Property(srcParam, sourceProp);
            var getterLambda = Expression.Lambda<Func<TSource, object>>(Expression.Convert(srcAccess, typeof(object)), srcParam);
            var getter = getterLambda.Compile();

            // Build setter
            var destParam = Expression.Parameter(typeof(TDestination), "d");
            var valueParam = Expression.Parameter(typeof(object), "v");
            var destAccess = Expression.Property(destParam, destProp);
            var assign = Expression.Assign(destAccess, Expression.Convert(valueParam, destProp.PropertyType));
            var setter = Expression.Lambda<Action<TDestination, object>>(assign, destParam, valueParam).Compile();

            // Use strongly-typed wrapper
            _mappings.Add(new MappingAction<TSource, TDestination, object>(
                src => getter(src),
                (dest, val) => setter(dest, val)
            ));

            return this;
        }


        /// <summary>
        /// Reverse mapping: TDestination → TSource
        /// </summary>
        public MappingBuilder<TDestination, TSource> ReverseMap()
        {
            var reverseBuilder = new MappingBuilder<TDestination, TSource>();

            // Auto-map properties with same names
            var sourceProps = typeof(TSource).GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(p => p.CanRead);
            var destProps = typeof(TDestination).GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(p => p.CanWrite);

            foreach (var sProp in sourceProps)
            {
                var dProp = destProps.FirstOrDefault(p => p.Name.Equals(sProp.Name, StringComparison.OrdinalIgnoreCase));
                if (dProp != null)
                {
                    // Use the same PropertyInfo-based ForMember
                    reverseBuilder.ForMember(dProp);
                }
            }

            // Register reverse mapping in the ModelMapper singleton
            ModelMapperInstance.Instance.RegisterMapping(reverseBuilder);

            return reverseBuilder;
        }

        public MappingBuilder<TSource, TDestination> SetFactory(Func<TSource, TDestination> factory)
        {
            _factory = factory;
            return this;
        }

        public Func<TSource, TDestination> Build()
        {
            return src =>
            {
                var dest = _factory != null ? _factory(src) : Activator.CreateInstance<TDestination>();
                foreach (var mapping in _mappings)
                    mapping.Apply(src, dest);
                return dest!;
            };
        }
    }

}
