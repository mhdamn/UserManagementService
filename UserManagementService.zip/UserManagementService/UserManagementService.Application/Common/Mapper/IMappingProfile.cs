﻿namespace UserManagementService.Application.Common.Mapper
{
    public interface IMappingProfile
    {
    }
}
