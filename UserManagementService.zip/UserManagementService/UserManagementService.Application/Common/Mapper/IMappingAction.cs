﻿namespace UserManagementService.Application.Common.Mapper
{
    // Strongly-typed mapping action (no object boxing)
    public interface IMappingAction<TSource, TDestination>
    {
        void Apply(in TSource source, TDestination destination);
    }
}
