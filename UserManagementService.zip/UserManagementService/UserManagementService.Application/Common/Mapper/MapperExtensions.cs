﻿namespace UserManagementService.Application.Common.Mapper
{
    public static class MapperExtensions
    {
        public static TDestination Map<TDestination>(this object source)
        {
            return ModelMapperInstance.Instance.Map<TDestination>(source);
        }
    }

}
