﻿using System.Reflection;

namespace UserManagementService.Application.Common.Mapper
{
    public class ModelMapper
    {
        private readonly Dictionary<(Type, Type), Delegate> _mappings = new();

        // Start defining a mapping
        public MappingBuilder<TSource, TDestination> CreateMap<TSource, TDestination>()
        {
            var builder = new MappingBuilder<TSource, TDestination>();

            // Auto-map convention-based properties by name
            var destProps = typeof(TDestination).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                                                .Where(p => p.CanWrite);

            foreach (var destProp in destProps)
            {
                var sourceProp = typeof(TSource).GetProperty(destProp.Name);
                if (sourceProp != null && sourceProp.CanRead)
                {

                    builder.ForMember(destProp);
                }
            }


            RegisterMapping(builder);

            return builder;
        }
        public void RegisterMapping<TSource, TDestination>(MappingBuilder<TSource, TDestination> builder)
        {
            builder.SetFactory(MappingFactoryHelper.CreateFactory<TSource, TDestination>());

            // Wrap builder into a Func<dynamic, TDestination> for storage
            _mappings[(typeof(TSource), typeof(TDestination))] = new Func<dynamic, TDestination>(src =>
            {
                var func = builder.Build();
                return func((TSource)src);
            });
        }

        // Map a source object to destination
        public TDestination Map<TDestination>(object source)
        {
            var key = (source.GetType(), typeof(TDestination));

            if (_mappings.TryGetValue(key, out var del))
            {
                var func = del as Func<dynamic, TDestination>;
                if (func != null)
                    return func((dynamic)source);

                throw new InvalidOperationException("Invalid mapping stored for this type.");
            }

            // Fallback: Auto-map by convention
            return AutoMapByConvention<TDestination>(source);
        }

        private static TDestination AutoMapByConvention<TDestination>(object source)
        {
            var destType = typeof(TDestination);
            var destProps = destType.GetProperties(BindingFlags.Public | BindingFlags.Instance)
                                    .Where(p => p.CanWrite);

            var sourceProps = source.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)
                                    .Where(p => p.CanRead)
                                    .ToDictionary(p => p.Name, p => p, StringComparer.OrdinalIgnoreCase);

            // Use your existing MappingFactoryHelper
            var factory = MappingFactoryHelper.CreateFactory<object, TDestination>();
            var destObj = factory(source);

            // Map properties by name (override factory-set values if needed)
            foreach (var destProp in destProps)
            {
                if (sourceProps.TryGetValue(destProp.Name, out var sourceProp))
                {
                    var value = sourceProp.GetValue(source);
                    destProp.SetValue(destObj, value);
                }
            }

            return destObj;
        }
    }

}
