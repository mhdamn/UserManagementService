﻿namespace UserManagementService.Application.Common.Mapper
{
    public abstract class Profile : IMappingProfile
    {
        protected static ModelMapper Mapper => ModelMapperInstance.Instance;

        protected static MappingBuilder<TSource, TDestination> CreateMap<TSource, TDestination>()
        {
            return Mapper.CreateMap<TSource, TDestination>();
        }
    }

}
