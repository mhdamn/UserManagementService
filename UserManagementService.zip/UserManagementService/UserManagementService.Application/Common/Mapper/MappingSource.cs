﻿namespace UserManagementService.Application.Common.Mapper
{
    // Wrapper for MapFrom-style
    public class MappingSource<TSource>
    {
        private readonly TSource _source;
        public MappingSource(TSource source) => _source = source;

        public TMember MapFrom<TMember>(Func<TSource, TMember> func) => func(_source);
    }
}
