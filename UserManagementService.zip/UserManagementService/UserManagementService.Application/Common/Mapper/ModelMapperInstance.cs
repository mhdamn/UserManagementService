﻿namespace UserManagementService.Application.Common.Mapper
{
    // Singleton instance
    public static class ModelMapperInstance
    {
        private static readonly Lazy<ModelMapper> _instance = new(() => new ModelMapper());
        public static ModelMapper Instance => _instance.Value;
    }

}
