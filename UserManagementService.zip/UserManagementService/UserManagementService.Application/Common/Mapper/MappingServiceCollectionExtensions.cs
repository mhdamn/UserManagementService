﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace UserManagementService.Application.Common.Mapper
{
    public static class MappingServiceCollectionExtensions
    {
        public static IServiceCollection AddMapper(this IServiceCollection services, params Assembly[] assemblies)
        {
            foreach (var assembly in assemblies)
            {
                var profileTypes = assembly.GetTypes()
                    .Where(t => typeof(IMappingProfile).IsAssignableFrom(t)
                                && !t.IsInterface && !t.IsAbstract);

                foreach (var type in profileTypes)
                {
                    services.AddTransient(type);                // Register profile in DI
                    Activator.CreateInstance(type);            // Instantiate to register mappings
                }
            }

            return services;
        }
    }

}
