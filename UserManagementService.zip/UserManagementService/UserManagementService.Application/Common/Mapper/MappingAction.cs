﻿namespace UserManagementService.Application.Common.Mapper
{
    // Holds a typed getter and setter for a member
    public sealed class MappingAction<TSource, TDestination, TMember> : IMappingAction<TSource, TDestination>
    {
        private readonly Func<TSource, TMember> _getter;
        private readonly Action<TDestination, TMember> _setter;

        public MappingAction(Func<TSource, TMember> getter, Action<TDestination, TMember> setter)
        {
            _getter = getter ?? throw new ArgumentNullException(nameof(getter));
            _setter = setter ?? throw new ArgumentNullException(nameof(setter));
        }

        // Use in/ref to avoid copying large structs (in for source, ref for dest)
        public void Apply(in TSource source, TDestination destination)
        {
            _setter(destination, _getter(source));
        }
    }
}
