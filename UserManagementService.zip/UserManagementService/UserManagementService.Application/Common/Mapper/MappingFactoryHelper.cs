﻿using System.Reflection;

namespace UserManagementService.Application.Common.Mapper
{
    public static class MappingFactoryHelper
    {
        public static Func<TSource, TDestination> CreateFactory<TSource, TDestination>()
        {
            var ctor = typeof(TDestination)
                .GetConstructors()
                .OrderByDescending(c => c.GetParameters().Length)
                .FirstOrDefault();

            if (ctor == null)
                throw new InvalidOperationException($"Type {typeof(TDestination).Name} has no accessible constructors.");

            // Parameterless constructor exists
            if (ctor.GetParameters().Length == 0)
            {
                return src => (TDestination)Activator.CreateInstance(typeof(TDestination))!;
            }

            //  Constructor with parameters (record or complex class)
            return src =>
            {
                var args = ctor.GetParameters()
                               .Select(p =>
                               {
                                   // Try to find matching source property by name (ignore case)
                                   var sourceProp = typeof(TSource).GetProperty(
                                       p.Name,
                                       BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance
                                   );

                                   // If not found or source is object, use default value
                                   return sourceProp?.GetValue(src) ?? GetDefault(p.ParameterType);
                               })
                               .ToArray();

                return (TDestination)ctor.Invoke(args);
            };
        }

        private static object? GetDefault(Type type) => type.IsValueType ? Activator.CreateInstance(type) : null;
    }

}
