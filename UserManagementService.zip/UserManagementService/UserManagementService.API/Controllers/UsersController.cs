using Microsoft.AspNetCore.Mvc;
using UserManagementService.Application.Common.CQRS;
using UserManagementService.Application.Users.Commands;
using UserManagementService.Application.Users.DTOs.Commands;
using UserManagementService.Application.Users.Queries;

namespace UserManagementService.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController(IDispatcher dispatcher) : ControllerBase
{
    private readonly IDispatcher _dispatcher = dispatcher;

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateUserRequestDto request)
    {
        var id = await _dispatcher.Send(new CreateUserCommand(request));
        return CreatedAtAction(nameof(GetById), new { id }, new { id });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(Guid id)
    {
        var user = await _dispatcher.Query(new GetUserByIdQuery(id));
        if (user == null) return NotFound();
        return Ok(user);
    }

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10, [FromQuery] string? nameFilter = null)
    {
        var query = new GetAllUsersQuery(new PagingParameters(pageNumber, pageSize), nameFilter);
        var result = await _dispatcher.Query(query);
        return Ok(result);
    }
}
