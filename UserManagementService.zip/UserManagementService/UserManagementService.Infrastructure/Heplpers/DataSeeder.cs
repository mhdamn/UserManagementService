﻿using UserManagementService.Application.Contracts.Repositories;
using UserManagementService.Domain.Entities;

namespace UserManagementService.Infrastructure.Helpers
{
    public class DataSeeder(IRepository<User> userRepository)
    {
        private readonly IRepository<User> _userRepository = userRepository;
        public async Task SeedAsync()
        {

            if (!await _userRepository.AnyAsync(u => true)) // check if any users exist
            {
                var users = new List<User>
                {
                    User.Create(Guid.NewGuid(), "Alice Johnson", "alice@example.com"),
                    User.Create(Guid.NewGuid(), "Mohammed","Ameen", "ameen@example.com"),
                    User.Create(Guid.NewGuid(), "Mohammed",string.Empty, "mohammed@example.com")
                };

                await userRepository.AddRangeAsync(users);
            }
        }
    }
}
