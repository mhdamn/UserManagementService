using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using UserManagementService.Application.Contracts.Repositories;
using UserManagementService.Infrastructure.Helpers;
using UserManagementService.Infrastructure.Persistence;
using UserManagementService.Infrastructure.Repositories;

namespace UserManagementService.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services)
    {
        services.AddDbContext<AppDbContext>(options => options.UseInMemoryDatabase("UserManagementDb"));
        services.AddScoped(typeof(IRepository<>), typeof(EfRepository<>));
        services.AddTransient<DataSeeder>();
        return services;
    }

    public static async Task SeedDataAsync(this IServiceProvider services)
    {
        // Resolve DataSeeder and run seeding
        using (var scope = services.CreateScope())
        {
            var seeder = scope.ServiceProvider.GetRequiredService<DataSeeder>();
            await seeder.SeedAsync();
        }
    }
}
