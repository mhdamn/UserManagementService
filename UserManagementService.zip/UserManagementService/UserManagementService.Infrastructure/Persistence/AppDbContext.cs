using Microsoft.EntityFrameworkCore;
using UserManagementService.Domain.Entities;

namespace UserManagementService.Infrastructure.Persistence;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // EF Core automatic seed
        modelBuilder.Entity<User>().HasData(
            User.Create(Guid.NewGuid(), "Alice Johnson", "alice@example.com"),
            User.Create(Guid.NewGuid(), "Bob Smith", "bob@example.com"),
            User.Create(Guid.NewGuid(), "Charlie Brown", "charlie@example.com")
        );
    }
}
