using Microsoft.EntityFrameworkCore;
using UserManagementService.Application.Contracts.Repositories;
using UserManagementService.Infrastructure.Persistence;

namespace UserManagementService.Infrastructure.Repositories;


public class EfRepository<TEntity> : IRepository<TEntity> where TEntity : class
{
    private readonly AppDbContext _context;
    private readonly DbSet<TEntity> _dbSet;

    public EfRepository(AppDbContext context)
    {
        _context = context;
        _dbSet = _context.Set<TEntity>();
    }

    public async Task AddAsync(TEntity entity) { await _dbSet.AddAsync(entity); await _context.SaveChangesAsync(); }
    public async Task AddRangeAsync(IEnumerable<TEntity> entities) { await _dbSet.AddRangeAsync(entities); await _context.SaveChangesAsync(); }
    public async Task UpdateAsync(TEntity entity) { _dbSet.Update(entity); await _context.SaveChangesAsync(); }
    public async Task DeleteAsync(TEntity entity) { _dbSet.Remove(entity); await _context.SaveChangesAsync(); }
    public async Task<bool> AnyAsync(Func<TEntity, bool> predicate) => _dbSet.Any(predicate);
    public async Task<TEntity?> GetByIdAsync(Guid id) => await _dbSet.FindAsync(id);
    public async Task<IEnumerable<TEntity>> GetAllAsync() => await _dbSet.ToListAsync();
    public IQueryable<TEntity> AsQueryable() => _dbSet.AsQueryable();
}
